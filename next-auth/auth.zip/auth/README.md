# Custom Auth example

```bash
$ npm install cookie bcryptjs mongoose 
```

#### Using middleware, cookies and hashing

## screenshot session vs jwt zeigen

### Package iron-session

Add files in lib/session.js

Used in API route

https://github.com/vvo/iron-session#coding-best-practices

https://github.com/vercel/next.js/tree/canary/examples/with-iron-session


https://fullstackdigital.io/blog/authentication-starter-kit-for-next-js-and-mongodb/
https://github.com/aplauche/nextauth-mongodb-starter