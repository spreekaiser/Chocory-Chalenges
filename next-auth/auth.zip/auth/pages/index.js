import Signup from './Signup';


export default function Home() {
  return (
    <>
      <Signup />
    </>
  )
}
